# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project

import math
from collections.abc import Iterable
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers.models.attention import FeedForward
from diffusers.models.embeddings import PixArtAlphaTextProjection, TimestepEmbedding, Timesteps
from diffusers.models.modeling_outputs import Transformer2DModelOutput
from vllm.distributed import (
    get_tensor_model_parallel_rank,
    get_tensor_model_parallel_world_size,
    tensor_model_parallel_all_reduce,
)
from vllm.distributed.utils import get_pp_indices
from vllm.logger import init_logger
from vllm.model_executor.layers.conv import Conv3dLayer
from vllm.model_executor.layers.linear import ColumnParallelLinear, LinearBase, QKVParallelLinear, RowParallelLinear
from vllm.model_executor.layers.quantization.base_config import QuantizationConfig
from vllm.model_executor.model_loader.weight_utils import default_weight_loader
from vllm.model_executor.models.utils import (
    PPMissingLayer,
    is_pp_missing_parameter,
    make_empty_intermediate_tensors_factory,
    make_layers,
)
from vllm.sequence import IntermediateTensors

from vllm_omni.diffusion.attention.backends.abstract import AttentionMetadata, VideoTokenLayout
from vllm_omni.diffusion.attention.layer import Attention
from vllm_omni.diffusion.distributed.parallel_state import (
    get_pipeline_parallel_world_size,
    is_pipeline_first_stage,
    is_pipeline_last_stage,
)
from vllm_omni.diffusion.distributed.sp_plan import (
    SequenceParallelInput,
    SequenceParallelOutput,
)
from vllm_omni.diffusion.forward_context import build_local_sp_padding_mask, get_forward_context
from vllm_omni.diffusion.layers.adalayernorm import AdaLayerNorm
from vllm_omni.diffusion.layers.norm import LayerNorm, RMSNorm
from vllm_omni.diffusion.layers.rope import RotaryEmbeddingWan
from vllm_omni.platforms import current_omni_platform
from vllm_omni.quantization.mxfp4_config import NPUMxfp4LinearMethod

logger = init_logger(__name__)


class DistributedRMSNorm(nn.Module):
    """
    RMSNorm that computes global RMS across tensor parallel ranks.
    This ensures mathematically equivalent results to non-TP execution.
    """

    def __init__(self, hidden_size: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(hidden_size))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        tp_size = get_tensor_model_parallel_world_size()

        input_dtype = x.dtype
        x_float = x.float()
        local_sum_sq = (x_float**2).sum(dim=-1, keepdim=True)
        local_count = x.shape[-1]

        if tp_size > 1:
            global_sum_sq = tensor_model_parallel_all_reduce(local_sum_sq)
            global_count = local_count * tp_size
        else:
            global_sum_sq = local_sum_sq
            global_count = local_count

        rms = torch.sqrt(global_sum_sq / global_count + self.eps)

        output = (x_float / rms) * self.weight.float()
        return output.to(input_dtype)


class ColumnParallelGELU(nn.Module):
    """Column parallel linear with GELU activation."""

    def __init__(
        self,
        dim_in: int,
        dim_out: int,
        *,
        approximate: str = "tanh",
        bias: bool = True,
        quant_config: QuantizationConfig | None = None,
        prefix: str = "",
    ):
        super().__init__()
        self.proj = ColumnParallelLinear(
            dim_in,
            dim_out,
            bias=bias,
            gather_output=False,
            return_bias=False,
            quant_config=quant_config,
            prefix=f"{prefix}.proj" if prefix else "proj",
        )
        self.approximate = approximate

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.proj(x)
        return F.gelu(x, approximate=self.approximate)


class WanFeedForward(nn.Module):
    """
    TP-enabled FeedForward network for WAN2.2.
    Replaces diffusers FeedForward with ColumnParallel + RowParallel.
    """

    def __init__(
        self,
        dim: int,
        inner_dim: int,
        dim_out: int | None = None,
        bias: bool = True,
        quant_config: QuantizationConfig | None = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        dim_out = dim_out or dim

        # ColumnParallel: scatter to each tp_rank
        self.net_0 = ColumnParallelGELU(
            dim,
            inner_dim,
            approximate="tanh",
            bias=bias,
            quant_config=quant_config,
            prefix=f"{prefix}.net_0" if prefix else "net_0",
        )
        # Placeholder for weight loading compatibility
        self.net_1 = nn.Identity()
        # RowParallel: gather from each tp_rank
        self.net_2 = RowParallelLinear(
            inner_dim,
            dim_out,
            bias=bias,
            input_is_parallel=True,
            return_bias=False,
            quant_config=quant_config,
            prefix=f"{prefix}.net_2" if prefix else "net_2",
        )

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        hidden_states = self.net_0(hidden_states)
        hidden_states = self.net_1(hidden_states)
        hidden_states = self.net_2(hidden_states)
        return hidden_states


class WanRotaryPosEmbed(nn.Module):
    """
    Rotary position embeddings for 3D video data (temporal + spatial dimensions).
    """

    def __init__(
        self,
        attention_head_dim: int,
        patch_size: tuple[int, int, int],
        max_seq_len: int,
        theta: float = 10000.0,
    ):
        super().__init__()

        self.attention_head_dim = attention_head_dim
        self.patch_size = patch_size
        self.max_seq_len = max_seq_len

        # Split dimensions for temporal, height, width
        h_dim = w_dim = 2 * (attention_head_dim // 6)
        t_dim = attention_head_dim - h_dim - w_dim
        freqs_dtype = torch.float64 if current_omni_platform.supports_float64() else torch.float32

        freqs_cos = []
        freqs_sin = []

        for dim in [t_dim, h_dim, w_dim]:
            freq_cos, freq_sin = self._get_1d_rotary_pos_embed(dim, max_seq_len, theta, freqs_dtype)
            freqs_cos.append(freq_cos)
            freqs_sin.append(freq_sin)

        self.register_buffer("freqs_cos", torch.cat(freqs_cos, dim=1), persistent=False)
        self.register_buffer("freqs_sin", torch.cat(freqs_sin, dim=1), persistent=False)

    @staticmethod
    def _get_1d_rotary_pos_embed(
        dim: int,
        max_seq_len: int,
        theta: float,
        freqs_dtype: torch.dtype,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Generate 1D rotary position embeddings."""
        freqs = 1.0 / (theta ** (torch.arange(0, dim, 2, dtype=freqs_dtype) / dim))
        t = torch.arange(max_seq_len, dtype=freqs_dtype)
        freqs = torch.outer(t, freqs)
        # Repeat interleave for real representation
        freqs_cos = freqs.cos().float().repeat_interleave(2, dim=-1)
        freqs_sin = freqs.sin().float().repeat_interleave(2, dim=-1)
        return freqs_cos.float(), freqs_sin.float()

    def forward(self, hidden_states: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        batch_size, num_channels, num_frames, height, width = hidden_states.shape
        p_t, p_h, p_w = self.patch_size
        ppf, pph, ppw = num_frames // p_t, height // p_h, width // p_w

        split_sizes = [
            self.attention_head_dim - 2 * (self.attention_head_dim // 3),
            self.attention_head_dim // 3,
            self.attention_head_dim // 3,
        ]

        freqs_cos = self.freqs_cos.split(split_sizes, dim=1)
        freqs_sin = self.freqs_sin.split(split_sizes, dim=1)

        freqs_cos_f = freqs_cos[0][:ppf].view(ppf, 1, 1, -1).expand(ppf, pph, ppw, -1)
        freqs_cos_h = freqs_cos[1][:pph].view(1, pph, 1, -1).expand(ppf, pph, ppw, -1)
        freqs_cos_w = freqs_cos[2][:ppw].view(1, 1, ppw, -1).expand(ppf, pph, ppw, -1)

        freqs_sin_f = freqs_sin[0][:ppf].view(ppf, 1, 1, -1).expand(ppf, pph, ppw, -1)
        freqs_sin_h = freqs_sin[1][:pph].view(1, pph, 1, -1).expand(ppf, pph, ppw, -1)
        freqs_sin_w = freqs_sin[2][:ppw].view(1, 1, ppw, -1).expand(ppf, pph, ppw, -1)

        freqs_cos = torch.cat([freqs_cos_f, freqs_cos_h, freqs_cos_w], dim=-1).reshape(1, ppf * pph * ppw, 1, -1)
        freqs_sin = torch.cat([freqs_sin_f, freqs_sin_h, freqs_sin_w], dim=-1).reshape(1, ppf * pph * ppw, 1, -1)

        return freqs_cos.to(hidden_states.device), freqs_sin.to(hidden_states.device)


class WanImageEmbedding(nn.Module):
    """Image embedding module for I2V tasks."""

    def __init__(self, in_features: int, out_features: int, pos_embed_seq_len: int | None = None):
        super().__init__()

        self.norm1 = LayerNorm(in_features)
        self.ff = FeedForward(in_features, out_features, mult=1, activation_fn="gelu")
        self.norm2 = LayerNorm(out_features)
        if pos_embed_seq_len is not None:
            self.pos_embed = nn.Parameter(torch.zeros(1, pos_embed_seq_len, in_features))
        else:
            self.pos_embed = None

    def forward(self, encoder_hidden_states_image: torch.Tensor) -> torch.Tensor:
        if self.pos_embed is not None:
            batch_size, seq_len, embed_dim = encoder_hidden_states_image.shape
            encoder_hidden_states_image = encoder_hidden_states_image.view(-1, 2 * seq_len, embed_dim)
            encoder_hidden_states_image = encoder_hidden_states_image + self.pos_embed

        hidden_states = self.norm1(encoder_hidden_states_image)
        hidden_states = self.ff(hidden_states)
        hidden_states = self.norm2(hidden_states)
        return hidden_states


class WanTimeTextImageEmbedding(nn.Module):
    """Combined time, text, and image condition embeddings."""

    def __init__(
        self,
        dim: int,
        time_freq_dim: int,
        time_proj_dim: int,
        text_embed_dim: int,
        image_embed_dim: int | None = None,
        pos_embed_seq_len: int | None = None,
    ):
        super().__init__()

        self.timesteps_proj = Timesteps(num_channels=time_freq_dim, flip_sin_to_cos=True, downscale_freq_shift=0)
        self.time_embedder = TimestepEmbedding(in_channels=time_freq_dim, time_embed_dim=dim)
        self.act_fn = nn.SiLU()
        self.time_proj = nn.Linear(dim, time_proj_dim)
        self.text_embedder = PixArtAlphaTextProjection(text_embed_dim, dim, act_fn="gelu_tanh")

        self.image_embedder = None
        if image_embed_dim is not None:
            self.image_embedder = WanImageEmbedding(image_embed_dim, dim, pos_embed_seq_len=pos_embed_seq_len)

    def forward(
        self,
        timestep: torch.Tensor,
        encoder_hidden_states: torch.Tensor,
        encoder_hidden_states_image: torch.Tensor | None = None,
        timestep_seq_len: int | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor | None]:
        timestep = self.timesteps_proj(timestep)
        if timestep_seq_len is not None:
            timestep = timestep.unflatten(0, (-1, timestep_seq_len))

        time_embedder_dtype = next(iter(self.time_embedder.parameters())).dtype
        if timestep.dtype != time_embedder_dtype and time_embedder_dtype != torch.int8:
            timestep = timestep.to(time_embedder_dtype)
        temb = self.time_embedder(timestep).type_as(encoder_hidden_states)
        timestep_proj = self.time_proj(self.act_fn(temb))

        encoder_hidden_states = self.text_embedder(encoder_hidden_states)
        if encoder_hidden_states_image is not None:
            encoder_hidden_states_image = self.image_embedder(encoder_hidden_states_image)

        return temb, timestep_proj, encoder_hidden_states, encoder_hidden_states_image


class TimestepProjPrepare(nn.Module):
    """Prepares timestep_proj for sequence parallel in TI2V models.

    Encapsulates the unflatten operation for timestep_proj to enable _sp_plan sharding.
    """

    def forward(
        self,
        timestep_proj: torch.Tensor,
        ts_seq_len: int | None,
    ) -> torch.Tensor:
        if ts_seq_len is not None:
            # TI2V mode: [batch, seq_len, 6, inner_dim]
            timestep_proj = timestep_proj.unflatten(2, (6, -1))
        else:
            # T2V mode: [batch, 6, inner_dim]
            timestep_proj = timestep_proj.unflatten(1, (6, -1))
        return timestep_proj


class OutputScaleShiftPrepare(nn.Module):
    """Prepares output scale/shift for SP sharding in TI2V models."""

    def __init__(self, inner_dim: int):
        super().__init__()
        self.scale_shift_table = nn.Parameter(torch.randn(1, 2, inner_dim) / inner_dim**0.5)

    def forward(self, temb: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if temb.ndim == 3:
            # TI2V: [B, seq, D] -> 3D outputs for SP sharding
            shift, scale = (self.scale_shift_table.unsqueeze(0).to(temb.device) + temb.unsqueeze(2)).chunk(2, dim=2)
            shift = shift.squeeze(2)
            scale = scale.squeeze(2)
        else:
            # T2V: [B, D] -> 2D outputs (skip SP sharding via expected_dims=3)
            shift, scale = (self.scale_shift_table.to(temb.device) + temb.unsqueeze(1)).chunk(2, dim=1)
            shift = shift.squeeze(1)
            scale = scale.squeeze(1)
        return shift, scale


class WanSelfAttention(nn.Module):
    """
    Optimized self-attention module using vLLM layers.
    """

    def __init__(
        self,
        dim: int,
        num_heads: int,
        head_dim: int,
        eps: float = 1e-5,
        dropout: float = 0.0,
        quant_config: QuantizationConfig | None = None,
        prefix: str = "",
    ):
        super().__init__()

        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.inner_dim = num_heads * head_dim

        # Fused QKV projection using vLLM's optimized layer
        self.to_qkv = QKVParallelLinear(
            hidden_size=dim,
            head_size=head_dim,
            total_num_heads=num_heads,
            bias=True,
            quant_config=quant_config,
            prefix=f"{prefix}.to_qkv" if prefix else "to_qkv",
        )

        self.num_heads = self.to_qkv.num_heads
        self.num_kv_heads = self.to_qkv.num_kv_heads
        self.tp_inner_dim = self.num_heads * head_dim

        # QK normalization using vLLM's RMSNorm
        if get_tensor_model_parallel_world_size() > 1:
            self.norm_q = DistributedRMSNorm(self.tp_inner_dim, eps=eps)
            self.norm_k = DistributedRMSNorm(self.tp_inner_dim, eps=eps)
        else:
            self.norm_q = RMSNorm(self.tp_inner_dim, eps=eps)
            self.norm_k = RMSNorm(self.tp_inner_dim, eps=eps)

        self.to_out = RowParallelLinear(
            self.inner_dim,
            dim,
            bias=True,
            input_is_parallel=True,
            return_bias=False,
            quant_config=quant_config,
            prefix=f"{prefix}.to_out" if prefix else "to_out",
        )
        self.dropout = nn.Dropout(dropout)

        self.rotary_embedding = RotaryEmbeddingWan(is_neox_style=False, half_head_dim=True)

        # Unified attention layer
        self.attn = Attention(
            num_heads=self.num_heads,
            head_size=head_dim,
            num_kv_heads=self.num_kv_heads,
            softmax_scale=1.0 / (head_dim**0.5),
            causal=False,
            role="self",
            qkv_layout="BSND",
            prefix=prefix,
        )

        # FastVideo VSA checkpoints may add a learned projection that gates
        # the compressed global branch. Zero initialization makes checkpoints
        # without these weights sparse-only, with no user-facing mode switch.
        self.to_gate_compress: ColumnParallelLinear | None = None
        if self.attn.attn_backend.get_name() == "FASTVIDEO_VSA":
            self.to_gate_compress = ColumnParallelLinear(
                dim,
                self.inner_dim,
                bias=True,
                gather_output=False,
                return_bias=False,
                quant_config=quant_config,
                prefix=f"{prefix}.to_gate_compress" if prefix else "to_gate_compress",
            )
            nn.init.zeros_(self.to_gate_compress.weight)
            if self.to_gate_compress.bias is not None:
                nn.init.zeros_(self.to_gate_compress.bias)

    def forward(
        self,
        hidden_states: torch.Tensor,
        rotary_emb: tuple[torch.Tensor, torch.Tensor] | None = None,
        attn_metadata: AttentionMetadata | None = None,
    ) -> torch.Tensor:
        # Fused QKV projection
        qkv, _ = self.to_qkv(hidden_states)

        q_size = self.num_heads * self.head_dim
        kv_size = self.num_kv_heads * self.head_dim
        query, key, value = qkv.split([q_size, kv_size, kv_size], dim=-1)

        # Apply QK normalization
        query = self.norm_q(query)
        key = self.norm_k(key)

        # Reshape for multi-head attention
        query = query.unflatten(2, (self.num_heads, self.head_dim))
        key = key.unflatten(2, (self.num_kv_heads, self.head_dim))
        value = value.unflatten(2, (self.num_kv_heads, self.head_dim))

        if self.to_gate_compress is not None:
            gate_result = self.to_gate_compress(hidden_states)
            gate_compress = gate_result[0] if isinstance(gate_result, tuple) else gate_result
            gate_compress = gate_compress.unflatten(2, (self.num_heads, self.head_dim))
            if attn_metadata is None:
                attn_metadata = AttentionMetadata(extra={"gate_compress": gate_compress})
            else:
                attn_metadata.extra["gate_compress"] = gate_compress

        # Apply rotary embeddings
        if rotary_emb is not None:
            freqs_cos, freqs_sin = rotary_emb
            query = self.rotary_embedding(query, freqs_cos, freqs_sin)
            key = self.rotary_embedding(key, freqs_cos, freqs_sin)

        # Compute attention using unified attention layer
        hidden_states = self.attn(query, key, value, attn_metadata)
        hidden_states = hidden_states.flatten(2, 3)
        hidden_states = hidden_states.type_as(query)

        # Output projection
        hidden_states = self.to_out(hidden_states)
        hidden_states = self.dropout(hidden_states)

        return hidden_states


class WanCrossAttention(nn.Module):
    """
    Optimized cross-attention module using vLLM layers.
    Handles both text cross-attention and optional image cross-attention (I2V).
    """

    def __init__(
        self,
        dim: int,
        num_heads: int,
        head_dim: int,
        eps: float = 1e-5,
        dropout: float = 0.0,
        added_kv_proj_dim: int | None = None,
        quant_config: QuantizationConfig | None = None,
        prefix: str = "",
    ):
        super().__init__()

        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.inner_dim = num_heads * head_dim
        self.kv_inner_dim = head_dim * num_heads  # For cross-attention, K/V come from encoder

        # Query projection
        self.to_q = ColumnParallelLinear(
            dim,
            self.inner_dim,
            bias=True,
            gather_output=False,
            return_bias=False,
            quant_config=quant_config,
            prefix=f"{prefix}.to_q" if prefix else "to_q",
        )

        # Separate K and V projections for cross-attention
        self.to_k = ColumnParallelLinear(
            dim,
            self.kv_inner_dim,
            bias=True,
            gather_output=False,
            return_bias=False,
            quant_config=quant_config,
            prefix=f"{prefix}.to_k" if prefix else "to_k",
        )

        self.to_v = ColumnParallelLinear(
            dim,
            self.kv_inner_dim,
            bias=True,
            gather_output=False,
            return_bias=False,
            quant_config=quant_config,
            prefix=f"{prefix}.to_v" if prefix else "to_v",
        )

        tp_size = get_tensor_model_parallel_world_size()
        self.num_heads = num_heads // tp_size
        self.tp_inner_dim = self.num_heads * head_dim

        # QK normalization
        if get_tensor_model_parallel_world_size() > 1:
            self.norm_q = DistributedRMSNorm(self.tp_inner_dim, eps=eps)
            self.norm_k = DistributedRMSNorm(self.tp_inner_dim, eps=eps)
        else:
            self.norm_q = RMSNorm(self.tp_inner_dim, eps=eps)
            self.norm_k = RMSNorm(self.tp_inner_dim, eps=eps)

        # Optional added KV projections for I2V (image embeddings)
        self.added_kv_proj_dim = added_kv_proj_dim
        if added_kv_proj_dim is not None:
            self.add_k_proj = ColumnParallelLinear(
                added_kv_proj_dim,
                self.inner_dim,
                bias=True,
                gather_output=False,
                return_bias=False,
                quant_config=quant_config,
                prefix=f"{prefix}.add_k_proj" if prefix else "add_k_proj",
            )
            self.add_v_proj = ColumnParallelLinear(
                added_kv_proj_dim,
                self.inner_dim,
                bias=True,
                gather_output=False,
                return_bias=False,
                quant_config=quant_config,
                prefix=f"{prefix}.add_v_proj" if prefix else "add_v_proj",
            )
            if get_tensor_model_parallel_world_size() > 1:
                self.norm_added_k = DistributedRMSNorm(self.tp_inner_dim, eps=eps)
            else:
                self.norm_added_k = RMSNorm(self.tp_inner_dim, eps=eps)
        else:
            self.add_k_proj = None
            self.add_v_proj = None
            self.norm_added_k = None

        # Output projection
        self.to_out = RowParallelLinear(
            self.inner_dim,
            dim,
            bias=True,
            input_is_parallel=True,
            return_bias=False,
            quant_config=quant_config,
            prefix=f"{prefix}.to_out" if prefix else "to_out",
        )
        self.dropout = nn.Dropout(dropout)

        # Unified attention layer
        self.attn = Attention(
            num_heads=self.num_heads,
            head_size=head_dim,
            num_kv_heads=self.num_heads,
            softmax_scale=1.0 / (head_dim**0.5),
            causal=False,
            role="cross",
            qkv_layout="BSND",
            prefix=prefix,
            skip_sequence_parallel=True,
            # Wan2.2 cross-attn operates on short text-encoder sequences; runtime
            # Q/K/V quantization offers no perf win and degrades quality. Opt out until a
            # dedicated quant backend handles this case.
            disable_kv_quant=True,
        )

    def forward(
        self,
        hidden_states: torch.Tensor,
        encoder_hidden_states: torch.Tensor,
        attn_metadata: AttentionMetadata | None = None,
    ) -> torch.Tensor:
        # Handle I2V case where encoder_hidden_states contains both image and text
        encoder_hidden_states_img = None
        if self.add_k_proj is not None:
            # 512 is the context length of the text encoder, hardcoded for now
            image_context_length = encoder_hidden_states.shape[1] - 512
            encoder_hidden_states_img = encoder_hidden_states[:, :image_context_length]
            encoder_hidden_states = encoder_hidden_states[:, image_context_length:]

        # Query projection
        query = self.to_q(hidden_states)
        query = self.norm_q(query)

        # KV projection from encoder
        key = self.to_k(encoder_hidden_states)
        value = self.to_v(encoder_hidden_states)
        key = self.norm_k(key)

        # Reshape for multi-head attention
        query = query.unflatten(2, (self.num_heads, self.head_dim))
        key = key.unflatten(2, (self.num_heads, self.head_dim))
        value = value.unflatten(2, (self.num_heads, self.head_dim))

        # I2V: Additional attention with image embeddings
        hidden_states_img = None
        if encoder_hidden_states_img is not None:
            key_img = self.add_k_proj(encoder_hidden_states_img)
            value_img = self.add_v_proj(encoder_hidden_states_img)
            key_img = self.norm_added_k(key_img)

            key_img = key_img.unflatten(2, (self.num_heads, self.head_dim))
            value_img = value_img.unflatten(2, (self.num_heads, self.head_dim))

            hidden_states_img = self.attn(query, key_img, value_img, attn_metadata)
            hidden_states_img = hidden_states_img.flatten(2, 3)
            hidden_states_img = hidden_states_img.type_as(query)

        # Main cross-attention using unified attention layer
        hidden_states = self.attn(query, key, value, attn_metadata)
        hidden_states = hidden_states.flatten(2, 3)
        hidden_states = hidden_states.type_as(query)

        # Add image attention output if present
        if hidden_states_img is not None:
            hidden_states = hidden_states + hidden_states_img

        # Output projection
        hidden_states = self.to_out(hidden_states)
        hidden_states = self.dropout(hidden_states)

        return hidden_states


class WanTransformerBlock(nn.Module):
    """
    Transformer block for Wan model with self-attention, cross-attention, and FFN.
    Uses scale-shift modulation from timestep embeddings.
    """

    def __init__(
        self,
        dim: int,
        ffn_dim: int,
        num_heads: int,
        eps: float = 1e-6,
        added_kv_proj_dim: int | None = None,
        cross_attn_norm: bool = False,
        quant_config: QuantizationConfig | None = None,
        prefix: str = "",
    ):
        super().__init__()

        head_dim = dim // num_heads

        # 1. Self-attention
        self.norm1 = AdaLayerNorm(dim, elementwise_affine=False, eps=eps)
        self.attn1 = WanSelfAttention(
            dim=dim,
            num_heads=num_heads,
            head_dim=head_dim,
            eps=eps,
            quant_config=quant_config,
            prefix=f"{prefix}.attn1" if prefix else "attn1",
        )

        # 2. Cross-attention
        self.attn2 = WanCrossAttention(
            dim=dim,
            num_heads=num_heads,
            head_dim=head_dim,
            eps=eps,
            added_kv_proj_dim=added_kv_proj_dim,
            quant_config=quant_config,
            prefix=f"{prefix}.attn2" if prefix else "attn2",
        )
        self.norm2 = LayerNorm(dim, eps, elementwise_affine=True) if cross_attn_norm else nn.Identity()

        # 3. Feed-forward
        self.ffn = WanFeedForward(
            dim=dim,
            inner_dim=ffn_dim,
            dim_out=dim,
            quant_config=quant_config,
            prefix=f"{prefix}.ffn" if prefix else "ffn",
        )
        self.norm3 = AdaLayerNorm(dim, elementwise_affine=False, eps=eps)

        # Scale-shift table for modulation
        self.scale_shift_table = nn.Parameter(torch.randn(1, 6, dim) / dim**0.5)

    def forward(
        self,
        hidden_states: torch.Tensor,
        encoder_hidden_states: torch.Tensor,
        temb: torch.Tensor,
        rotary_emb: tuple[torch.Tensor, torch.Tensor],
        hidden_states_mask: torch.Tensor | None = None,
        vsa_dit_seq_shape: tuple[int, int, int] | None = None,
        preserve_vsa_all_blocks: bool = False,
    ) -> torch.Tensor:
        if temb.ndim == 4:
            # temb: batch_size, seq_len, 6, inner_dim (wan2.2 ti2v)
            shift_msa, scale_msa, gate_msa, c_shift_msa, c_scale_msa, c_gate_msa = (
                self.scale_shift_table.unsqueeze(0) + temb
            ).chunk(6, dim=2)
            shift_msa = shift_msa.squeeze(2)
            scale_msa = scale_msa.squeeze(2)
            gate_msa = gate_msa.squeeze(2)
            c_shift_msa = c_shift_msa.squeeze(2)
            c_scale_msa = c_scale_msa.squeeze(2)
            c_gate_msa = c_gate_msa.squeeze(2)
        else:
            # temb: batch_size, 6, inner_dim (wan2.1/wan2.2 14B)
            shift_msa, scale_msa, gate_msa, c_shift_msa, c_scale_msa, c_gate_msa = (
                self.scale_shift_table + temb
            ).chunk(6, dim=1)

        # 1. Self-attention
        norm_hidden_states = self.norm1(hidden_states, scale_msa, shift_msa).type_as(hidden_states)
        self_attn_extra = {}
        if vsa_dit_seq_shape is not None:
            self_attn_extra["vsa_dit_seq_shape"] = vsa_dit_seq_shape
        if preserve_vsa_all_blocks:
            self_attn_extra["preserve_vsa_all_blocks"] = True
        video_layout = None
        if vsa_dit_seq_shape is not None:
            grid = tuple(int(dim) for dim in vsa_dit_seq_shape)
            # Publish geometry independently of backend selection. Do not add
            # partial cu_seqlens/max_seqlen metadata to dense CUDA attention.
            video_layout = VideoTokenLayout(prefix_len=0, latent_grid=grid, used_len=math.prod(grid))
        self_attn_metadata = AttentionMetadata(
            attn_mask=hidden_states_mask, extra=self_attn_extra, video_layout=video_layout
        )
        attn_output = self.attn1(norm_hidden_states, rotary_emb, self_attn_metadata)
        hidden_states = (hidden_states + attn_output * gate_msa).type_as(hidden_states)

        # 2. Cross-attention
        norm_hidden_states = self.norm2(hidden_states).type_as(hidden_states)
        attn_output = self.attn2(norm_hidden_states, encoder_hidden_states, None)
        hidden_states = hidden_states + attn_output

        # 3. Feed-forward
        norm_hidden_states = self.norm3(hidden_states, c_scale_msa, c_shift_msa).type_as(hidden_states)
        ff_output = self.ffn(norm_hidden_states)
        hidden_states = (hidden_states + ff_output * c_gate_msa).type_as(hidden_states)

        return hidden_states


class WanTransformer3DModel(nn.Module):
    """
    Optimized Wan Transformer model for video generation using vLLM layers.

    This is an optimized version of the diffusers WanTransformer3DModel that uses
    vLLM's efficient QKVParallelLinear and RMSNorm implementations.

    Sequence Parallelism:
        This model supports non-intrusive SP via _sp_plan. The plan specifies:
        - RoPE (cos/sin) splitting via rope module's split_output
        - hidden_states splitting at first transformer block input
        - Output gathering at proj_out layer

        The video sequence (flattened patches) is parallelized across GPUs.

        Note: Our "Sequence Parallelism" (SP) corresponds to "Context Parallelism" (CP) in diffusers.

    Args:
        patch_size: 3D patch dimensions for video embedding (t_patch, h_patch, w_patch)
        num_attention_heads: Number of attention heads
        attention_head_dim: Dimension of each attention head
        in_channels: Number of input channels
        out_channels: Number of output channels
        text_dim: Input dimension for text embeddings
        freq_dim: Dimension for sinusoidal time embeddings
        ffn_dim: Intermediate dimension in feed-forward network
        num_layers: Number of transformer blocks
        cross_attn_norm: Enable cross-attention normalization
        eps: Epsilon value for normalization layers
        image_dim: Optional image embedding dimension for I2V
        added_kv_proj_dim: Optional added KV projection dimension for I2V
        rope_max_seq_len: Maximum sequence length for rotary embeddings
        pos_embed_seq_len: Optional position embedding sequence length
    """

    _repeated_blocks = ["WanTransformerBlock"]
    _layerwise_offload_blocks_attrs = ["blocks"]
    packed_modules_mapping = {
        "to_qkv": ["to_q", "to_k", "to_v"],
    }

    @staticmethod
    def _is_transformer_block(name: str, module) -> bool:
        """Match transformer blocks for HSDP sharding (e.g., blocks.0, blocks.1)."""
        return "blocks" in name and name.split(".")[-1].isdigit()

    _hsdp_shard_conditions = [_is_transformer_block]

    # Sequence Parallelism for Wan (following diffusers' _cp_plan pattern)
    #
    # The _sp_plan specifies sharding/gathering at module boundaries:
    # - rope: Split both RoPE outputs (freqs_cos, freqs_sin) via split_output=True
    # - timestep_proj_prepare: Split timestep_proj for TI2V models (4D tensor)
    # - _sp_shard_point: Split hidden_states before CacheDiT-wrapped transformer blocks
    # - proj_out: Gather outputs after the final projection layer
    #
    # Note: _sp_plan corresponds to diffusers' _cp_plan (Context Parallelism)
    _sp_plan = {
        # Shard RoPE embeddings after rope module computes them
        # auto_pad=True enables variable sequence length support
        "rope": {
            0: SequenceParallelInput(
                split_dim=1, expected_dims=4, split_output=True, auto_pad=True
            ),  # freqs_cos [1, seq, 1, dim]
            1: SequenceParallelInput(
                split_dim=1, expected_dims=4, split_output=True, auto_pad=True
            ),  # freqs_sin [1, seq, 1, dim]
        },
        # Shard timestep_proj for TI2V models (4D tensor: [batch, seq_len, 6, inner_dim])
        # This is only active when ts_seq_len is not None (TI2V mode)
        # Output is a single tensor, shard along dim=1 (sequence dimension)
        "timestep_proj_prepare": {
            0: SequenceParallelInput(
                split_dim=1, expected_dims=4, split_output=True, auto_pad=True
            ),  # [B, seq, 6, dim]
        },
        # Shard hidden_states before entering transformer blocks. This keeps
        # CacheDiT block wrappers aligned with the local SP shard.
        "_sp_shard_point": {
            0: SequenceParallelInput(split_dim=1, expected_dims=3, split_output=True, auto_pad=True),
        },
        # Shard output scale/shift for TI2V (3D); T2V outputs 2D and skips sharding
        "output_scale_shift_prepare": {
            0: SequenceParallelInput(split_dim=1, expected_dims=3, split_output=True, auto_pad=True),
            1: SequenceParallelInput(split_dim=1, expected_dims=3, split_output=True, auto_pad=True),
        },
        # Gather at proj_out (final linear projection before unpatchify)
        "proj_out": SequenceParallelOutput(gather_dim=1, expected_dims=3),
    }

    def __init__(
        self,
        patch_size: tuple[int, int, int] = (1, 2, 2),
        num_attention_heads: int = 40,
        attention_head_dim: int = 128,
        in_channels: int = 16,
        out_channels: int = 16,
        text_dim: int = 4096,
        freq_dim: int = 256,
        ffn_dim: int = 13824,
        num_layers: int = 40,
        cross_attn_norm: bool = True,
        eps: float = 1e-6,
        image_dim: int | None = None,
        added_kv_proj_dim: int | None = None,
        rope_max_seq_len: int = 1024,
        pos_embed_seq_len: int | None = None,
        quant_config: QuantizationConfig | None = None,
        layer_pp_rank: int | None = None,
        layer_pp_world: int | None = None,
    ):
        super().__init__()
        # Store config for compatibility
        self.config = type(
            "Config",
            (),
            {
                "patch_size": patch_size,
                "num_attention_heads": num_attention_heads,
                "attention_head_dim": attention_head_dim,
                "in_channels": in_channels,
                "out_channels": out_channels,
                "text_dim": text_dim,
                "freq_dim": freq_dim,
                "ffn_dim": ffn_dim,
                "num_layers": num_layers,
                "cross_attn_norm": cross_attn_norm,
                "eps": eps,
                "image_dim": image_dim,
                "added_kv_proj_dim": added_kv_proj_dim,
                "rope_max_seq_len": rope_max_seq_len,
                "pos_embed_seq_len": pos_embed_seq_len,
            },
        )()

        inner_dim = num_attention_heads * attention_head_dim
        out_channels = out_channels or in_channels

        # Optional WaveServe-style layer PP: split by (rank, world) without mocking
        # Omni's S·G process group. When unset, use the live pipeline-parallel group.
        if layer_pp_world is not None:
            if layer_pp_world < 1:
                raise ValueError(f"layer_pp_world must be positive, got {layer_pp_world}")
            pp_rank = 0 if layer_pp_rank is None else int(layer_pp_rank)
            if not 0 <= pp_rank < layer_pp_world:
                raise ValueError(f"layer_pp_rank {pp_rank} out of range for world {layer_pp_world}")
            pp_world = int(layer_pp_world)
            is_first = pp_rank == 0
            is_last = pp_rank == pp_world - 1
        else:
            if get_pipeline_parallel_world_size() == 0 and not is_pipeline_first_stage():
                raise RuntimeError(
                    "`initialize_model_parallel()` must be called before constructing `WanTransformer3DModel`"
                )
            pp_rank = None
            pp_world = None
            is_first = is_pipeline_first_stage()
            is_last = is_pipeline_last_stage()

        # 1. Patch & position embedding
        self.rope = WanRotaryPosEmbed(attention_head_dim, patch_size, rope_max_seq_len)
        # Patch embedding only on first PP stage; other stages receive hidden_states via P2P
        if is_first:
            self.patch_embedding = Conv3dLayer(
                in_channels=in_channels,
                out_channels=inner_dim,
                kernel_size=patch_size,
                stride=patch_size,
            )
        else:
            self.patch_embedding = PPMissingLayer()

        # 2. Condition embeddings
        self.condition_embedder = WanTimeTextImageEmbedding(
            dim=inner_dim,
            time_freq_dim=freq_dim,
            time_proj_dim=inner_dim * 6,
            text_embed_dim=text_dim,
            image_embed_dim=image_dim,
            pos_embed_seq_len=pos_embed_seq_len,
        )

        # DMD/FastVideo checkpoints retain VSA semantics when top-k selects every block.
        self.preserve_vsa_all_blocks = False

        # 3. Transformer blocks — partitioned across PP stages.
        def _make_block(prefix: str) -> WanTransformerBlock:
            return WanTransformerBlock(
                inner_dim,
                ffn_dim,
                num_attention_heads,
                eps,
                added_kv_proj_dim,
                cross_attn_norm,
                quant_config=quant_config,
                prefix=prefix,
            )

        if pp_world is not None:
            # Explicit (rank, world) slice — used by WaveServe Noisy PP layer groups.
            start_layer, end_layer = get_pp_indices(num_layers, pp_rank, pp_world)
            blocks: list[nn.Module] = []
            for idx in range(num_layers):
                if start_layer <= idx < end_layer:
                    blocks.append(_make_block(f"blocks.{idx}"))
                else:
                    blocks.append(PPMissingLayer())
            self.start_layer = start_layer
            self.end_layer = end_layer
            self.blocks = nn.ModuleList(blocks)
        else:
            # Production Omni PP: make_layers follows the live PP group.
            self.start_layer, self.end_layer, self.blocks = make_layers(
                num_layers,
                _make_block,
                prefix="blocks",
            )

        # 4. Output norm & projection — only on the last PP stage
        if is_last:
            self.norm_out = AdaLayerNorm(inner_dim, elementwise_affine=False, eps=eps)
            self.proj_out = nn.Linear(inner_dim, out_channels * math.prod(patch_size))
        else:
            self.norm_out, self.proj_out = PPMissingLayer(), PPMissingLayer()

        # SP helper modules
        self.timestep_proj_prepare = TimestepProjPrepare()
        self._sp_shard_point = nn.Identity()
        if is_last:
            self.output_scale_shift_prepare = OutputScaleShiftPrepare(inner_dim)
        else:
            self.output_scale_shift_prepare = PPMissingLayer()

        self.make_empty_intermediate_tensors = make_empty_intermediate_tensors_factory(["hidden_states"], inner_dim)

        # ROPE helper
        self._cached_rope_emb = None
        self._cached_rope_resolution = None
        self._validate_w4a8_fallback_layers(quant_config)

    def _validate_w4a8_fallback_layers(self, quant_config: QuantizationConfig | None) -> None:
        """Reject checkpoint aliases/typos before loading weights or running inference."""
        requested = tuple(getattr(quant_config, "w4a8_fallback_layers", []))
        self._w4a8_fallback_layers = requested
        self._local_w4a8_fallback_layers: tuple[str, ...] = ()
        if not requested:
            return
        modules = dict(self.named_modules())
        missing_pp_prefixes = [name for name, module in modules.items() if isinstance(module, PPMissingLayer)]
        local_layers = [
            name for name in requested if not any(name.startswith(prefix + ".") for prefix in missing_pp_prefixes)
        ]
        self._local_w4a8_fallback_layers = tuple(local_layers)
        invalid = [name for name in local_layers if not isinstance(modules.get(name), LinearBase)]
        if invalid:
            raise ValueError(
                "w4a8_fallback_layers requires exact runtime Linear paths relative to each Wan transformer; "
                f"unknown/non-Linear paths: {invalid}. Use attn1.to_qkv for fused self-attention, "
                "not checkpoint attn1.to_q/to_k/to_v names."
            )

    def _log_w4a8_fallback_load_summary(self, component_name: str) -> None:
        """Log post-load transforms/cache readiness, not numerical acceptance."""
        requested = self._w4a8_fallback_layers
        if not requested:
            return
        modules = dict(self.named_modules())
        local_layers = self._local_w4a8_fallback_layers
        selected_layers = [
            name for name in local_layers if getattr(modules[name].quant_method, "is_w4a8_fallback_layer", False)
        ]
        bf16_overrides = [name for name in local_layers if name not in selected_layers]
        processed = [
            name
            for name in selected_layers
            if getattr(modules[name], "_already_called_process_weights_after_loading", False)
        ]
        if not selected_layers:
            processing_state = "not-required"
        elif len(processed) == len(selected_layers):
            processing_state = "ready"
        else:
            processing_state = "not-ready"

        def qualified(names: Iterable[str]) -> list[str]:
            return [f"{component_name}.{name}" for name in names]

        logger.info(
            "Wan W4A8 post-load summary: component=%s; selected=%d %s; BF16 overrides=%d %s; "
            "weight/A8 processing state=%s (%d/%d selected layers processed); other PP ranks=%d",
            component_name,
            len(selected_layers),
            qualified(selected_layers),
            len(bf16_overrides),
            qualified(bf16_overrides),
            processing_state,
            len(processed),
            len(selected_layers),
            len(requested) - len(local_layers),
        )

    @property
    def dtype(self) -> torch.dtype:
        """Return the dtype of the model parameters."""
        return next(self.parameters()).dtype

    def forward(
        self,
        hidden_states: torch.Tensor,
        timestep: torch.LongTensor,
        encoder_hidden_states: torch.Tensor,
        encoder_hidden_states_image: torch.Tensor | None = None,
        intermediate_tensors: IntermediateTensors | None = None,
        return_dict: bool = True,
        attention_kwargs: dict[str, Any] | None = None,
    ) -> torch.Tensor | Transformer2DModelOutput | IntermediateTensors:
        batch_size, num_channels, num_frames, height, width = hidden_states.shape
        p_t, p_h, p_w = self.config.patch_size
        post_patch_num_frames = num_frames // p_t
        post_patch_height = height // p_h
        post_patch_width = width // p_w

        # Compute RoPE embeddings (sharded by _sp_plan via split_output=True)
        current_rope_resolution = (post_patch_num_frames, post_patch_height, post_patch_width)
        if self._cached_rope_resolution == current_rope_resolution and self._cached_rope_emb is not None:
            rotary_emb = self._cached_rope_emb
        else:
            freqs_cos, freqs_sin = self.rope(hidden_states)
            rotary_emb = (freqs_cos[..., 0::2].to(hidden_states.dtype), freqs_sin[..., 1::2].to(hidden_states.dtype))
            self._hidden_states_shape = hidden_states.shape
            self._cached_rope_emb = rotary_emb

        if is_pipeline_first_stage():
            # Patch embedding and flatten to sequence. SP sharding happens at
            # _sp_shard_point so downstream block wrappers see local tensors.
            hidden_states = self.patch_embedding(hidden_states)
            hidden_states = hidden_states.flatten(2).transpose(1, 2)
            hidden_states = self._sp_shard_point(hidden_states)
        else:
            if intermediate_tensors is None:
                raise RuntimeError("intermediate_tensors must be provided for non-first PP stages")
            hidden_states = intermediate_tensors["hidden_states"]

        # Handle timestep shape (2-D for TI2V, 1-D for T2V)
        if timestep.ndim == 2:
            ts_seq_len = timestep.shape[1]
            timestep = timestep.flatten()
        else:
            ts_seq_len = None

        # Compute conditioning on all PP stages.
        # Each stage needs temb/timestep_proj for scale-shift modulation in its local blocks.
        temb, timestep_proj, encoder_hidden_states, encoder_hidden_states_image = self.condition_embedder(
            timestep, encoder_hidden_states, encoder_hidden_states_image, timestep_seq_len=ts_seq_len
        )
        # Prepare timestep_proj via TimestepProjPrepare module
        # _sp_plan will shard timestep_proj via split_output=True (when ts_seq_len is not None)
        # This ensures timestep_proj sequence dimension matches sharded hidden_states
        timestep_proj = self.timestep_proj_prepare(timestep_proj, ts_seq_len)

        if encoder_hidden_states_image is not None:
            encoder_hidden_states = torch.concat([encoder_hidden_states_image, encoder_hidden_states], dim=1)

        hidden_states_mask = None
        ctx = get_forward_context()
        parallel_config = ctx.omni_diffusion_config.parallel_config
        if (
            parallel_config is not None
            and parallel_config.sequence_parallel_size > 1
            and parallel_config.mask_sp_padding
        ):
            hidden_states_mask = build_local_sp_padding_mask(
                hidden_states.shape[0],
                hidden_states.shape[1],
                hidden_states.device,
            )
            if hidden_states_mask.all():
                hidden_states_mask = None
        elif (
            parallel_config is not None
            and parallel_config.sequence_parallel_size > 1
            and not parallel_config.mask_sp_padding
            and ctx.sp_original_seq_len is not None
            and ctx.sp_padding_size > 0
        ):
            logger.warning_once(
                "SP auto-padding applied %d token(s) (seq_len=%d, ulysses_degree=%d). "
                "Padding tokens are not masked from attention (mask_sp_padding=False), "
                "which avoids the varlen attention path but may produce minor numerical differences. "
                "Set parallel_config.mask_sp_padding=True to restore strict masking.",
                ctx.sp_padding_size,
                ctx.sp_original_seq_len,
                parallel_config.sequence_parallel_size,
            )

        # Transformer blocks
        # Preserve the post-patch (T, H, W) grid so VSA can partition
        # the flattened DiT sequence into spatiotemporal blocks.
        vsa_dit_seq_shape = (post_patch_num_frames, post_patch_height, post_patch_width)
        for block in self.blocks[self.start_layer : self.end_layer]:
            hidden_states = block(
                hidden_states,
                encoder_hidden_states,
                timestep_proj,
                rotary_emb,
                hidden_states_mask,
                vsa_dit_seq_shape,
                self.preserve_vsa_all_blocks,
            )

        if not is_pipeline_last_stage():
            # Non-last PP stage: hand the token sequence to the caller via IntermediateTensors.
            # predict_noise will broadcast it to the next stage before calling that stage's forward.
            return IntermediateTensors({"hidden_states": hidden_states})

        # Output norm, projection & unpatchify
        shift, scale = self.output_scale_shift_prepare(temb)
        shift = shift.to(hidden_states.device)
        scale = scale.to(hidden_states.device)
        if shift.ndim == 2:  # T2V mode: unsqueeze for broadcasting
            shift = shift.unsqueeze(1)
            scale = scale.unsqueeze(1)

        hidden_states = self.norm_out(hidden_states, scale, shift).type_as(hidden_states)
        hidden_states = self.proj_out(hidden_states)

        hidden_states = hidden_states.reshape(
            batch_size, post_patch_num_frames, post_patch_height, post_patch_width, p_t, p_h, p_w, -1
        )
        hidden_states = hidden_states.permute(0, 7, 1, 4, 2, 5, 3, 6)
        output = hidden_states.flatten(6, 7).flatten(4, 5).flatten(2, 3)

        if not return_dict:
            return (output,)

        return Transformer2DModelOutput(sample=output)

    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        """
        Load weights from a pretrained model, handling the mapping from
        separate Q/K/V projections to fused QKV projections for self-attention.

        Diffusers weight names:
        - blocks.N.attn1.to_q/to_k/to_v -> fused to blocks.N.attn1.to_qkv (self-attention)
        - blocks.N.attn2.to_q/to_k/to_v -> kept separate (cross-attention)
        - blocks.N.attn1.norm_q/norm_k -> QK normalization for self-attention

        Returns:
            Set of parameter names that were successfully loaded.
        """
        tp_rank = get_tensor_model_parallel_rank()
        tp_size = get_tensor_model_parallel_world_size()
        # Stacked params mapping for self-attention QKV fusion.
        # Format: (param_name, shard_name, shard_id)
        # Note: Only fuse attn1 (self-attention), NOT attn2 (cross-attention)
        stacked_params_mapping = [
            # self-attention QKV fusion
            (".attn1.to_qkv", ".attn1.to_q", "q"),
            (".attn1.to_qkv", ".attn1.to_k", "k"),
            (".attn1.to_qkv", ".attn1.to_v", "v"),
        ]
        # Expose packed shard mappings for LoRA handling of fused projections.
        self.stacked_params_mapping = stacked_params_mapping

        # Remap scale_shift_table to new module location
        weight_name_remapping = {
            "scale_shift_table": "output_scale_shift_prepare.scale_shift_table",
        }

        params_dict = dict(self.named_parameters())
        single_scale_prefixes = {
            name
            for name, module in self.named_modules()
            if isinstance(getattr(module, "quant_method", None), NPUMxfp4LinearMethod)
        }

        def reject_dualscale_tensor(name: str) -> None:
            if name.endswith(".weight_dual_scale") and name.rsplit(".", 1)[0] in single_scale_prefixes:
                raise ValueError(
                    f"Single-scale mxfp4 cannot load DualScale tensor {name}; "
                    "changing quant_method does not convert a checkpoint."
                )

        loaded_params: set[str] = set()
        loaded_qkv_shards: dict[str, set[str]] = {}
        qkv_smooth_scales: dict[str, torch.Tensor] = {}

        for name, loaded_weight in weights:
            name = weight_name_remapping.get(name, name)
            original_name = name
            lookup_name = name

            # Handle QKV fusion for weight tensors (separate to_q/k/v → fused to_qkv).
            # Pre-fused to_qkv tensors (from offline MXFP8 merged checkpoint) fall
            # through to the else branch and are loaded directly.
            for param_name, weight_name, shard_id in stacked_params_mapping:
                if f"{weight_name}." not in original_name:
                    continue
                lookup_name = original_name.replace(f"{weight_name}.", f"{param_name}.", 1)
                reject_dualscale_tensor(lookup_name)
                # Skip weights that belong to PP stages other than this one
                if is_pp_missing_parameter(lookup_name, self) or lookup_name not in params_dict:
                    break
                param = params_dict[lookup_name]
                if lookup_name.endswith(".mul_scale"):
                    previous_scale = qkv_smooth_scales.get(lookup_name)
                    if previous_scale is not None and not torch.equal(previous_scale, loaded_weight):
                        raise ValueError(f"Fused Q/K/V must share the same Smooth tensor: {lookup_name}")
                    if previous_scale is None:
                        qkv_smooth_scales[lookup_name] = loaded_weight.clone()
                weight_loader = param.weight_loader
                weight_loader(param, loaded_weight, shard_id)
                loaded_params.add(original_name)
                if getattr(param, "output_dim", None) is None and not getattr(param, "needs_scalar_to_array", False):
                    # Shared input-channel Smooth is a complete tensor even
                    # when supplied under a single Q/K/V source name.
                    loaded_params.add(lookup_name)
                else:
                    shards = loaded_qkv_shards.setdefault(lookup_name, set())
                    shards.add(shard_id)
                    if shards == {"q", "k", "v"}:
                        loaded_params.add(lookup_name)
                break
            else:
                # diffusers: ffn.net.0.proj.weight -> our: ffn.net_0.proj.weight
                if ".ffn.net.0." in lookup_name:
                    lookup_name = lookup_name.replace(".ffn.net.0.", ".ffn.net_0.")
                elif ".ffn.net.2." in lookup_name:
                    lookup_name = lookup_name.replace(".ffn.net.2.", ".ffn.net_2.")

                if ".to_out.0." in lookup_name:
                    lookup_name = lookup_name.replace(".to_out.0.", ".to_out.")

                # Compatibility: some Wan conversion pipelines still keep
                # block modulation keys as `blocks.N.modulation` instead of
                # `blocks.N.scale_shift_table`.
                if lookup_name.endswith(".modulation"):
                    modulation_alias = lookup_name[: -len(".modulation")] + ".scale_shift_table"
                    if modulation_alias in params_dict:
                        lookup_name = modulation_alias

                # Skip weights that belong to PP stages other than this one
                if is_pp_missing_parameter(lookup_name, self):
                    continue

                reject_dualscale_tensor(lookup_name)
                if lookup_name not in params_dict:
                    logger.warning(f"Skipping weight {original_name} -> {lookup_name}")
                    continue

                param = params_dict[lookup_name]

                # Handle RMSNorm weights that need to be sharded for TP
                # These norms are applied after ColumnParallelLinear outputs,
                # so their weights must be sharded to match the sharded hidden dim
                if tp_size > 1 and any(
                    norm_name in lookup_name
                    for norm_name in [
                        ".attn1.norm_q.",
                        ".attn1.norm_k.",
                        ".attn2.norm_q.",
                        ".attn2.norm_k.",
                        ".attn2.norm_added_k.",
                    ]
                ):
                    shard_size = loaded_weight.shape[0] // tp_size
                    loaded_weight = loaded_weight[tp_rank * shard_size : (tp_rank + 1) * shard_size]

                weight_loader = getattr(param, "weight_loader", default_weight_loader)
                weight_loader(param, loaded_weight)
                loaded_params.update((original_name, lookup_name))

        return loaded_params
